package com.thevarungupta.employee.service.service;

import com.thevarungupta.employee.service.entity.Employee;
import com.thevarungupta.employee.service.payload.EmployeeDepartment;

import java.util.List;

public interface EmployeeService {
    List<Employee> getAllEmployees();
    Employee getEmployeeById(int id);
    Employee createEmployee(Employee employee);
    EmployeeDepartment getEmployeeWithDepartment(int employeeId);
}
