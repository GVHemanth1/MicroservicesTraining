package com.thevarungupta.employee.service.controller;

import com.thevarungupta.employee.service.entity.Employee;
import com.thevarungupta.employee.service.payload.EmployeeDepartment;
import com.thevarungupta.employee.service.repository.EmployeeRepository;
import com.thevarungupta.employee.service.service.EmployeeService;
import com.thevarungupta.employee.service.service.impl.EmployeeServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/api/employees")
@RestController
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployee(){
        var data = employeeService.getAllEmployees();
        return ResponseEntity.ok(data);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable() int id){
        var data = employeeService.getEmployeeById(id);
        return ResponseEntity.ok(data);
    }

    @PostMapping
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee){
        var data = employeeService.createEmployee(employee);
        return new ResponseEntity<>(data, HttpStatus.CREATED);
    }

    @GetMapping("/{id}/department")
    public ResponseEntity<EmployeeDepartment> getEmployeeWithDepartment(@PathVariable("id") int id){
        var data = employeeService.getEmployeeWithDepartment(id);
        return ResponseEntity.ok(data);
    }
}
